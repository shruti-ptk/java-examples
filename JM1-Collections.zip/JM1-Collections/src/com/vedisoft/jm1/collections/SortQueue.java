package com.vedisoft.jm1.collections;

import java.util.*;

public class SortQueue implements Comparator<Integer> {
	public int compare(Integer First, Integer Second) {
		return Second - First;
	}
}
